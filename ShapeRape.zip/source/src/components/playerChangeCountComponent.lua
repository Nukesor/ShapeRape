PlayerChangeCountComponent = class("PlayerChangeCountComponent", Component)

function PlayerChangeCountComponent:__init()
    self.count = 0
    self.ulti = 0
end