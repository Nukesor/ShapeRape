AchievementComponent = class("AchievementComponent", Component)

function AchievementComponent:__init()
    self.value = 1
end