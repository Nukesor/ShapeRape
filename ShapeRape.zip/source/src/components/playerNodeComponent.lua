PlayerNodeComponent = class("PlayerNodeComponent", Component)

function PlayerNodeComponent:__init(node)
    self.node = node
end