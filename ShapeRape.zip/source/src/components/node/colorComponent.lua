ColorComponent = class("ColorComponent", Component)

function ColorComponent:__init(r, g, b)
	self.r = r
	self.g = g
	self.b = b
end