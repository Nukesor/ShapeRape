CornerComponent = class("CornerComponent", Component)

function CornerComponent:__init(corner)
    self.corner = corner
end