ShapeComponent = class("ShapeComponent", Component)

function ShapeComponent:__init(shape)
    self.shape = shape
end