PowerUpComponent = class("PowerUpComponent", Component)

function PowerUpComponent:__init(type)
    self.type = type
end