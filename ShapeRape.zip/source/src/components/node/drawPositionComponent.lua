DrawPositionComponent = class("DrawPositionComponent", Component)

function DrawPositionComponent:__init()
end