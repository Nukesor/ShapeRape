ShapeDeletionComponent = class("ShapeDeletionComponent", Component)

function ShapeDeletionComponent:__init(shape)
    self.shape = shape
end