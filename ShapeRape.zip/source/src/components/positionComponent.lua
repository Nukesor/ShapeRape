PositionComponent = class("PositionComponent", Component)

function PositionComponent:__init(x, y)
    self.x = x
    self.y = y
end