UltiComponent = class("UltiComponent", Component)

function UltiComponent:__init()
    self.timer = 8
end