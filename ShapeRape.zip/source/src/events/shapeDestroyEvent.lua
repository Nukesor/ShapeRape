ShapeDestroyEvent = class("ShapeDestroyEvent")


function ShapeDestroyEvent:__init(shape)
    self.shape = shape
end