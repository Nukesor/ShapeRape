PositionComponent = class("PositionComponent")

function PositionComponent:__init(x, y)
    self.x = x
    self.y = y
end