ExampleComponent = class("ExampleComponent", Component)

function ExampleComponent:__init(time)
	self.timer = time
end