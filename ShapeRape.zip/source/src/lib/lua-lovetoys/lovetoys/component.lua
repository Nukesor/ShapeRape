Component = class("Component")

-- Just a superclass to identify components
function Component:__init()
end